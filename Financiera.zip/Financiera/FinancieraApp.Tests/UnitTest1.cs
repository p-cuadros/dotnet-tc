using DotNet.Testcontainers.Builders;
using DotNet.Testcontainers.Containers;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using FinancieraApp; //ResidentApi.Logic.Database;
using FinancieraApp.Entidades;
using System.Text.Json;
namespace FinancieraApp.Tests;

[TestFixture]
public class ClientesControllerTests
{
    private const string Database = "mysql";
    private const string Username = "root";
    private const string Password = "upt.2024";
    private const ushort MySqlPort = 3306;

    private WebApplicationFactory<Program> _factory;
    private IContainer _container;

    [OneTimeSetUp]
    public async Task OneTimeSetUp()
    {
        // Set up Testcontainers SQL Server container
        _container = new ContainerBuilder()
            .WithImage("mariadb")
            .WithPortBinding(MySqlPort, true)
            // .WithEnvironment("ACCEPT_EULA", "Y")
            // .WithEnvironment("SQLCMDUSER", Username)
            // .WithEnvironment("SQLCMDPASSWORD", Password)
            .WithEnvironment("MYSQL_ROOT_PASSWORD", Password)
            .WithWaitStrategy(Wait.ForUnixContainer().UntilPortIsAvailable(MySqlPort))
            .Build();
        //Start Container
        await _container.StartAsync();

        var host = _container.Hostname;
        var port = _container.GetMappedPublicPort(MySqlPort);

        // Replace connection string in DbContext
        //Server=localhost; User ID=root; Password=upt.2024; Database=FinancieraBD
        string connectionString = $"Server={host};Port={port};Database={Database};User ID={Username};Password={Password}";
        _factory = new WebApplicationFactory<Program>()
            .WithWebHostBuilder(builder =>
            {
                builder.ConfigureServices(services =>
                {
                    services.AddDbContext<FinancieraContexto>(options =>
                        options.UseMySql(connectionString,ServerVersion.AutoDetect(connectionString)));
                });
            });
        Thread.Sleep(15000);
        // Initialize database
        using var scope = _factory.Services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<FinancieraContexto>();
        dbContext.Database.Migrate();
    }

    [OneTimeTearDown]
    public async Task OneTimeTearDown()
    {
        await _container.StopAsync();
        await _container.DisposeAsync();
        _factory.Dispose();
    }

    [Test]
    public async Task GetAllResidents_ReturnsEmptyList()
    {
        var client = _factory.CreateClient();

        var response = await client.GetAsync("/api/Clientes");

        response.EnsureSuccessStatusCode();
        var content = await response.Content.ReadAsStringAsync();
        var clientes = JsonSerializer.Deserialize<List<Cliente>>(content);

        clientes.Should().NotBeNull();
        clientes.Should().BeEmpty();
    }

}