
namespace FinancieraApp;

public class DatabaseInitializer
{
    private readonly FinancieraContexto _dbContext;

    public DatabaseInitializer(FinancieraContexto dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task InitializeAsync()
        => await _dbContext.Database.EnsureCreatedAsync();
}